//
//  ParseJSON.swift
//  Login
//
//  Created by Administrator on 8/31/16.
//  Copyright © 2016 Administrator. All rights reserved.
//

import Foundation

class ParseJSON {
    
    func parseJSON() {
        
    }
    
    static func parseJSONFromData(jsonData: NSData?) -> [String : AnyObject]?
    {
        if let data = jsonData {
            do {
                let jsonDictionary = try NSJSONSerialization.JSONObjectWithData(data, options: NSJSONReadingOptions.MutableContainers) as? [String : AnyObject]
                return jsonDictionary
                
            } catch let error as NSError {
                print("error processing json data: \(error.localizedDescription)")
            }
        }
        
        return nil
    }

}