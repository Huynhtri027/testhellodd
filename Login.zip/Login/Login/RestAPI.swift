//
//  RestAPI.swift
//  Login
//
//  Created by Administrator on 8/30/16.
//  Copyright © 2016 Administrator. All rights reserved.
//

import Foundation
import UIKit

protocol APIDelegate {
    func APIResponseArrived(response:AnyObject)
}

class RestAPI {
    
    let username: String
    let password: String
    let ip: String
    var delegate:APIDelegate! = nil
    
    init (username: String, password: String, ip: String) {
        self.username = username
        self.password = password
        self.ip = ip
    }
    
    // --------- GET ------
    // doRequestGet with Basic
    func doRequestGet() {

        let url: String = "http://\(self.ip)/api/v1/VitalQIP%20Organization/v4subnet/192.168.88.0/v4addresses.json"
        let nsUrl = NSURL(string: url);
        
        let request = NSMutableURLRequest(URL:nsUrl!);
        request.HTTPMethod = "GET"
        request.setValue("Basic qipman:qipman", forHTTPHeaderField: "Authentication") // Basic
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let task = NSURLSession.sharedSession().dataTaskWithRequest(request) {
            (data: NSData?, response: NSURLResponse?, error: NSError?) -> Void in
            if error != nil {
                print("error=\(error)")
                return
            }
            //print ("body \(data)")
            if let responseData = data {
                do {
                    let json = try NSJSONSerialization.JSONObjectWithData(responseData, options: NSJSONReadingOptions.AllowFragments)
                    print ("JSON Data: \(json)")
                    self.delegate.APIResponseArrived(json as! String)

                } catch let error as NSError {
                    print(error.localizedDescription)
                }
            }
        }
        task.resume()
    }
    
    // --------- GET ------
    // doRequestGet with Token
    func doRequestGet(token: String) {
        let url: String = "http://\(self.ip)/api/v1/VitalQIP%20Organization/v4subnet/172.16.0.0/v4addresses.json"
        let nsUrl = NSURL(string: url); // http
        
        let request = NSMutableURLRequest(URL:nsUrl!);
        request.HTTPMethod = "GET"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("Token \(token)", forHTTPHeaderField: "Authentication") // Token
        
        let task = NSURLSession.sharedSession().dataTaskWithRequest(request) {
            (data: NSData?, response: NSURLResponse?, error: NSError?) -> Void in
            if error != nil {
                print("error=\(error)")
                return
            }
            //print ("body \(data)")
            if let responseData = data {
                do {
                    let json = try NSJSONSerialization.JSONObjectWithData(responseData, options: NSJSONReadingOptions.AllowFragments)
                    
                    self.delegate.APIResponseArrived(json)
                } catch let error as NSError {
                    print(error.localizedDescription)
                }
            }
        }
        task.resume()

    }
    
    
    // --------- POST ------
    func doRequestPost(){

        let requestBody = [
            "username": self.username,
            "password": self.password,
            "expires":7200
        ]
        let url: String = "http://\(self.ip)/api/login"
        let theJSONData = try? NSJSONSerialization.dataWithJSONObject( requestBody , options: NSJSONWritingOptions())
        let jsonString = NSString(data: theJSONData!, encoding: NSASCIIStringEncoding)
        let session = NSURLSession.sharedSession()
        
        let nsUrl = NSURL(string: url)
        let request = NSMutableURLRequest(URL: nsUrl!)
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.HTTPMethod = "POST"
        request.HTTPBody = jsonString!.dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion:true)
        let task = session.dataTaskWithRequest(request, completionHandler: { ( data: NSData?, response: NSURLResponse?, error: NSError?) -> Void in
            //print ("*** RESPONSE: \(response!)")
            if let httpResponse = response as? NSHTTPURLResponse {
                // check Status Code: 200, 400, 401, 500 ...
                switch httpResponse.statusCode {
                case 200:
                    if let infoAuthentication = httpResponse.allHeaderFields["Authentication"] as? String {
                        self.delegate.APIResponseArrived(infoAuthentication as AnyObject)
                    }
                default:
                    print (httpResponse.statusCode)
                }
            }
        })
        task.resume()
    }
    
    
    // --------- POST ------
    func doRequestPost (username: String, password: String, ip: String, completion: (NSString)->()) {
        let requestBody = [
            "username": username,
            "password":password,
            "expires":7200
        ]
        let url: String = "http://\(ip)/api/login"
        
        let theJSONData = try? NSJSONSerialization.dataWithJSONObject( requestBody , options: NSJSONWritingOptions())
        let jsonString = NSString(data: theJSONData!, encoding: NSASCIIStringEncoding)
        let session = NSURLSession.sharedSession()
        
        let urlPath = NSURL(string: url)
        let request = NSMutableURLRequest(URL: urlPath!)
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.HTTPMethod = "POST"
        request.HTTPBody = jsonString!.dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion:true)
        let task = session.dataTaskWithRequest(request, completionHandler: { ( data: NSData?, response: NSURLResponse?, error: NSError?) -> Void in
            //print ("*** RESPONSE: \(response!)")
            if let httpResponse = response as? NSHTTPURLResponse {
                switch httpResponse.statusCode {
                case 200:
                    if let infoAuthentication = httpResponse.allHeaderFields["Authentication"] as? String {
                        completion(infoAuthentication) // transfer token to VC
                    }
                default:
                    print (httpResponse.statusCode)
                }
            }
        })
        task.resume()
    }
    
}