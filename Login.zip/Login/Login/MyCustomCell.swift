//
//  MyCustomCell.swift
//  Login
//
//  Created by Administrator on 8/31/16.
//  Copyright © 2016 Administrator. All rights reserved.
//

import UIKit

class MyCustomCell: UITableViewCell {

    @IBOutlet weak var IP: UILabel!
    
}
