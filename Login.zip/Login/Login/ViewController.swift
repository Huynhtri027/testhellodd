//
//  ViewController.swift
//  Login
//
//  Created by Administrator on 8/29/16.
//  Copyright © 2016 Administrator. All rights reserved.
//

import UIKit

class ViewController: UIViewController, APIDelegate {

    //Outlet
    @IBOutlet weak var txtUrl: UITextField!
    @IBOutlet weak var txtOrg: UITextField!
    @IBOutlet weak var txtUsername: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    // variable
    var token: NSString = ""
    var varTransfer: NSUserDefaults!
    var userName: String!
    var passWord: String!
    var iP: String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    
    @IBAction func btnLogin(sender: AnyObject) {
        
        varTransfer = NSUserDefaults()
        userName = txtUsername.text!
        passWord = txtPassword.text!
        iP = txtUrl.text!
        let restApi = RestAPI(username: userName, password: passWord, ip: iP)
        restApi.delegate = self
        restApi.doRequestPost()
        if self.token.length > 0 {
            
            varTransfer.setObject(userName, forKey: "user")
            varTransfer.setObject(passWord, forKey: "pass")
            varTransfer.setObject(iP, forKey: "ip")
            varTransfer.setObject(self.token as String, forKey: "token")
            if let vc = self.storyboard?.instantiateViewControllerWithIdentifier("IPTableVC") {
                self.presentViewController(vc, animated: true, completion: nil) //
            } else {
                print ("nil")
            }
        }
    }
    func APIResponseArrived(response: AnyObject) {
        //print ("toooooo \(response)")
        self.token = response as! String
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

}
