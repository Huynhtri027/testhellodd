package com.lucent.qip.validator.bases;

import com.lucent.qip.validator.QipValidator;

public abstract class StringValidator extends QipValidator<String>{

	protected boolean isNullOrEmpty(String string) {
		return string == null || string.isEmpty();
	}
	
	//max length, min length....
}
