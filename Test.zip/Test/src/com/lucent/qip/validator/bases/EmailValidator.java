package com.lucent.qip.validator.bases;

import java.util.regex.Pattern;

import com.lucent.qip.validator.ValidationException;

public class EmailValidator extends StringValidator {
	private static final String EMAIL_REGEX = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$";
	private static final Pattern EMAIL_PATTERN = java.util.regex.Pattern.compile(EMAIL_REGEX);
	
	@Override
	public void validate(String t) {
		boolean valid = EMAIL_PATTERN.matcher(t).matches();
		if (!valid) {
			throw new ValidationException("Email is invalid");
		}
		
	}

}
