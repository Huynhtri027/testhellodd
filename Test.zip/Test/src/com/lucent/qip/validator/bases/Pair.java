package com.lucent.qip.validator.bases;

import java.io.Serializable;

public class Pair<T, U> implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -4602939942289119388L;
	private T m_t;
	private U m_u;

	public Pair(T first, U second) {
		m_t = first;
		m_u = second;
	}

	public T getFirst() {
		return m_t;
	}

	public U getSecond() {
		return m_u;
	}

	@SuppressWarnings("rawtypes")
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (!(o instanceof Pair))
			return false;

		final Pair pair = (Pair) o;

		if (m_t != null ? !m_t.equals(pair.m_t) : pair.m_t != null)
			return false;
		if (m_u != null ? !m_u.equals(pair.m_u) : pair.m_u != null)
			return false;

		return true;
	}

	public int hashCode() {
		int result;
		result = (m_t != null ? m_t.hashCode() : 0);
		result = 29 * result + (m_u != null ? m_u.hashCode() : 0);
		return result;
	}

	public String toString() {
		return "{ " + m_t + ", " + m_u + " }";
	}
}
