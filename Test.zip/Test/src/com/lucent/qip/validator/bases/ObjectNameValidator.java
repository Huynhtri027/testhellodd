package com.lucent.qip.validator.bases;

import com.lucent.qip.validator.ValidationException;

public class ObjectNameValidator extends StringValidator {
	
	@Override
	public void validate(String t) {
		if (isNullOrEmpty(t)) {
			throw new ValidationException("Invalid Object name");
		}
	}

}
