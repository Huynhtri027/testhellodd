package com.lucent.qip.validator.bases;

import com.lucent.qip.validator.QipValidator;
import com.lucent.qip.validator.ValidationException;

public class RequiredFieldValidator extends QipValidator<Object>{

	@Override
	public void validate(Object t) {
		if(t == null) {
			throw new ValidationException("This field is required");
		}
		if (t instanceof String && (t == null || t.toString().isEmpty())) {
			throw new ValidationException("This field is required");
		}
		
	}
}
