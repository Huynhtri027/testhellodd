package com.lucent.qip.validator;

public interface Validator<T> {
	public void validate(T t);
	
}
