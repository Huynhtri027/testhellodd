package com.lucent.qip.validator;

public class QipValidationBuilder implements SpecificValidator {
	@SuppressWarnings("rawtypes")
	private QipValidator validator = new QipValidator<>();

	protected QipValidationBuilder() {
		
	}
	
	public static QipValidationBuilder getInstance() {
		return new QipValidationBuilder();
	}
	
	
	@SuppressWarnings("unchecked")
	public <V> QipValidationBuilder build(Validator<V> validatr, V object) {
		validator.addValidator(validatr, object);
		return this;
	}
	
	@Override
	public void validate() {
		validator.validate();
	}
}

interface SpecificValidator {
	public void validate();
}
