package com.lucent.qip.validator.myobject;

import java.util.List;

public class Kclass {
	private List<Student> students;
	private String name;

	public Kclass(List<Student> person, String name) {
		super();
		this.students = person;
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public List<Student> getStudents() {
		return students;
	}

}
