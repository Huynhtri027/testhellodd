package com.lucent.qip.validator.myobject;


import com.lucent.qip.validator.QipValidator;
import com.lucent.qip.validator.bases.RequiredFieldValidator;

public class KlassValidator extends QipValidator<Kclass> {

	@Override
	protected void build(Kclass t) {
		addValidator(new RequiredFieldValidator(), t.getName());
		
		for (Student student: t.getStudents()) {
			addValidator(new PersonAddingValidator(), student);
		}
	}
}
