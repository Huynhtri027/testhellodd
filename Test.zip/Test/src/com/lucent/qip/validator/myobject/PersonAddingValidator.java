package com.lucent.qip.validator.myobject;

import com.lucent.qip.validator.QipValidator;
import com.lucent.qip.validator.bases.EmailValidator;
import com.lucent.qip.validator.bases.ObjectNameValidator;

public class PersonAddingValidator extends QipValidator<Student> {

	@Override
	protected void build(Student v) {
		addValidator(new EmailValidator(), v.getEmail());
		addValidator(new ObjectNameValidator(), v.getName());
	}

}
