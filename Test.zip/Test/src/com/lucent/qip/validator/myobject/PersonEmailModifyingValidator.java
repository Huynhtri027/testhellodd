package com.lucent.qip.validator.myobject;

import com.lucent.qip.validator.QipValidator;
import com.lucent.qip.validator.bases.EmailValidator;

public class PersonEmailModifyingValidator extends QipValidator<Student> {

	@Override
	protected void build(Student v) {
		addValidator(new EmailValidator(), v.getEmail());
	}

}
