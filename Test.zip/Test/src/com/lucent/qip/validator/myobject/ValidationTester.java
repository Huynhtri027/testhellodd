package com.lucent.qip.validator.myobject;

import java.util.Arrays;

import javax.ws.rs.core.UriBuilder;

import com.lucent.qip.validator.QipValidationBuilder;
import com.lucent.qip.validator.QipValidator;
import com.lucent.qip.validator.Validator;
import com.lucent.qip.validator.bases.EmailValidator;
import com.lucent.qip.validator.bases.RequiredFieldValidator;

public class ValidationTester {
	public static void main(String[] args) {
		/*Student object = new Student("testgmail.com", "test");
		PersonAddingValidator validator = new PersonAddingValidator();
		validator.validate(object);
		
		PersonEmailModifyingValidator personEmailModifyingValidator = new PersonEmailModifyingValidator();
		personEmailModifyingValidator.validate(new Student("test", ""));
		
		
		Kclass myKclass = new Kclass(Arrays.asList(new Student("test@test.com", "")), "MyKlass");
		KlassValidator klassValidator = new KlassValidator();
		klassValidator.validate(myKclass);*/
		
		
		Student student = new Student("test@gmail.com", "test");
		QipValidationBuilder.getInstance().build(new EmailValidator(), student.getEmail()).build(new RequiredFieldValidator(), student.getName()).validate();
		
	}
}
