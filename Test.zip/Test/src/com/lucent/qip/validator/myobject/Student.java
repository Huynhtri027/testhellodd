package com.lucent.qip.validator.myobject;

public class Student {
	private String email;
	private String name;

	public Student() {

	}
	
	public Student(String email, String name) {
		this.email = new String(email);
		this.name = new String(name);
	}

	public String getEmail() {
		return email;
	}

	public String getName() {
		return name;
	}

}
