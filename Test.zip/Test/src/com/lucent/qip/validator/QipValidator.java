package com.lucent.qip.validator;

import java.util.ArrayList;
import java.util.List;

import com.lucent.qip.validator.bases.Pair;

public class QipValidator<T> implements Validator<T> {
	
	@SuppressWarnings("rawtypes")
	List<Pair<Validator, Object>> validators = new ArrayList<>();
	
	public void validate(T t) {
		build(t);
		validate();
	}
	
	protected void build(T t) {
		
	}
	
	@SuppressWarnings("rawtypes")
	protected final <V> Validator<T> addValidator(Validator<V> validator, V object) {
		validators.add(new Pair<Validator, Object>(validator, object));
		return this;
	}


	@SuppressWarnings({ "unchecked", "rawtypes" })
	protected final void validate() {
		for (Pair<Validator, Object> pair : validators) {
			pair.getFirst().validate(pair.getSecond());
		}
	}
}
